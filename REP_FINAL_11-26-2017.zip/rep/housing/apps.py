from django.apps import AppConfig


class HousingConfig(AppConfig):
    name = 'housing'
